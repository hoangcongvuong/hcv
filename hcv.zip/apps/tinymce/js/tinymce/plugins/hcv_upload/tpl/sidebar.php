<section id="sidebar" class="row">
    <ul>
        <li class="fl">
            <a href="file_upload.php?multi_select=<?php echo $_GET['multi_select'] ?>">Upload</a>
        </li>
        
        <li class="fl">
            <a href="gallery.php?multi_select=<?php echo $_GET['multi_select'] ?>">Thư viện</a>
        </li>
        
        <li class="fl">
            <a href="by_link.php?multi_select=<?php echo $_GET['multi_select'] ?>">Chèn bằng link</a>
        </li>
    </ul>
</section>
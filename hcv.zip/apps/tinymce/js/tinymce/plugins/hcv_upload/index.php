<?php
	include dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . '/media/tpl/file_upload.php';
<?php
	if(!defined('SECURE_CHECK')) die('Stop');
?>

404
<section id="sidebar" class="row">
    <ul>
        <li class="fl">
            <a href="<?php echo SITE_URL ?>/media/tpl/file_upload.php">Upload</a>
        </li>
        
        <li class="fl">
            <a href="<?php echo SITE_URL ?>/media/tpl/gallery.php">Thư viện</a>
        </li>
        
        <li class="fl">
            <a href="<?php echo SITE_URL ?>/media/tpl/by_link.php">Chèn bằng link</a>
        </li>
    </ul>
</section>
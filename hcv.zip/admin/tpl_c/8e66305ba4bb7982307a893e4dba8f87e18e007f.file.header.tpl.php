<?php /* Smarty version Smarty-3.1.18, created on 2014-05-19 06:35:16
         compiled from "tpl\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:181785378fe8b1f8248-20700101%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8e66305ba4bb7982307a893e4dba8f87e18e007f' => 
    array (
      0 => 'tpl\\header.tpl',
      1 => 1400473984,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '181785378fe8b1f8248-20700101',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5378fe8b2f2b80_53094975',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5378fe8b2f2b80_53094975')) {function content_5378fe8b2f2b80_53094975($_smarty_tpl) {?><?php }} ?>

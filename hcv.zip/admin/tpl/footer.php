<?php
	if(!defined('SECURE_CHECK')) die('Stop');
?>
    </div>
</div>
</body>
</html>
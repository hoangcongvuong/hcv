<?php
if(!defined('SECURE_CHECK')) die('Stop');

if(isset($_POST['submit_category_content']))
{
    /**
     * Error notification and all mysql statement
     */
    $error_notification = '<span style="color:red">Error : </span><br />';
    $hcv_sql_statement = '';
    $sql_statement = '';
    
    $obj_DB = new models_DB;

    $parent_category = '';  
    
    $category_fields = array(
        'term_title'                   => $_POST['category_title'],
        'term_url'                     => $_POST['category_url'],
        'term_description'             => $_POST['category_description'],
        'term_image'                   => $_POST['category_image'],
        'term_parent_category'         => $_POST['parent_category'],
        'term_secure_key'              => random_string()
    );
    
    
      
  
    
    if( $_POST['category_url'] == '' )
    {
        $error_notification .= '- Your url is empty<br />';
    }
    else
    {
        $obj_query = new models_query;
        $query_terms = array();
        ///echo $obj_query->url_exists($_POST['category_url']);
        if($obj_query->url_exists($_POST['category_url']) == true ) $error_notification .= 'Your url already exists';
       
        else
        {
            if(!$obj_DB->insert($category_fields, 'term')) 
            {
                $error_notification .= $obj_DB->last_result_status;
            }    
            else
            {
                $current_category = 'SELECT term_id FROM term WHERE term_url=\'' . $_POST['category_url'] . '\'';
                $category_id = $obj_DB->get($current_category);
                $category_id = $category_id[0]['term_id'];
                
                header('Location: index.php?action=edit_category&body=category_form&category_id='.$category_id . '&messenger=1');
            }
        }
        
        
    }
}

/**
 * Read template
 */
$tpl = new views_view();

$tpl->assign('title', 'Add new category');    
$tpl->assign('css', array(
    SITE_URL . '/apps/bootstrap-3.1.1-dist/css/bootstrap.min.css',
    SITE_URL . '/admin/' . 'css/reset.css',
    SITE_URL . '/admin/' . 'css/admin.css'
));
$tpl->assign('script',array(
    SITE_URL . '/apps/js/jquery-1.9.1.min.js',
    SITE_URL . '/apps/bootstrap-3.1.1-dist/js/bootstrap.min.js',
    SITE_URL . '/admin/js/admin.js',
    SITE_URL . '/apps/tinymce/js/tinymce/jquery.tinymce.min.js',
    SITE_URL . '/apps/tinymce/js/tinymce/tinymce.min.js'
    //SITE_URL . '/apps/tinymce3/tinymce/jscripts/tiny_mce/tiny_mce.js'
));


$obj_query = new models_query;
$query_terms = array();
$get_the_category = $obj_query->query_terms($query_terms);

foreach($get_the_category as $v_get_the_category)
{
    //echo 'adsdfsfd<br />';
    $category_id[] = $v_get_the_category['term_id'];
    $category_name[] = $v_get_the_category['term_title'];
}


$tpl->assign('category_id', $category_id);
$tpl->assign('category_name', $category_name);

$tpl->assign('action', 'Publish');

if(isset($category_fields['category_title'])) $tpl->assign('category_title', $category_fields['category_title']);
else $tpl->assign('category_title', '');

if(isset($category_fields['category_url'])) $tpl->assign('category_url', $category_fields['category_url']);
else $tpl->assign('category_url', '');

if(isset($category_fields['parent_category'])) $tpl->assign('parent_category', $category_fields['parent_category']);
else $tpl->assign('parent_category', '');

if(isset($category_fields['category_image'])) $tpl->assign('category_image', $category_fields['category_image']);
else $tpl->assign('category_image', '');

if(isset($category_fields['category_description'])) $tpl->assign('category_description', $category_fields['category_description']);
else $tpl->assign('category_description', '');

/**
 * END Read template
 */